// Post request 
function addTaskDetails(){
        var taskName = document.getElementById("addtaskname").value;
        var time = document.getElementById("addtime").value;
        var status = document.getElementById("addstatus").value;
        var data = {
            "name": taskName,
            "expiryDate" : time,
            "status" : status
        };
        var xhr = new XMLHttpRequest();
        xhr.open( "POST","http://34.71.224.0:8080/api/tasks",true); 
        xhr.setRequestHeader('Authorization',"Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ1c2VyMSIsImF1dGgiOiJST0xFX1VTRVIiLCJleHAiOjE2MTc0MzMzOTl9._VY8Ao2E4a4C5_3aWpRh3HzPBJPlQ4SWdzAlMObp89r3rEx2jQXs-x_Lz7ozNDZuIdxI9zuExRUFYCQaYwfRUw");
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.send(JSON.stringify(data));
        xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 400) {
            window.location.replace("index.html");
        }
        else {
            alert("Failed to add");
        }
        }
}
// Put request 
function editTaskDetails(){
    var taskName = document.getElementById("taskname").value;
    var time = document.getElementById("time").value;
    var status = document.getElementById("status").value;
    var id = document.getElementById("saveChanges").value;
    var data = {
        "id" : id,
        "name" : taskName,
        "expiryDate" : time,
        "status" : status
    };
    var xhr = new XMLHttpRequest();
    xhr.open( "PUT","http://34.71.224.0:8080/api/tasks",true);
    xhr.setRequestHeader('Authorization',"Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ1c2VyMSIsImF1dGgiOiJST0xFX1VTRVIiLCJleHAiOjE2MTc0MzMzOTl9._VY8Ao2E4a4C5_3aWpRh3HzPBJPlQ4SWdzAlMObp89r3rEx2jQXs-x_Lz7ozNDZuIdxI9zuExRUFYCQaYwfRUw");
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(data));
    xhr.onload = function () {
    if (xhr.status >= 200 && xhr.status < 400) {
            window.location.replace("index.html");
    }
    else {
        alert("Failed to edit");
    }
 }
}


 
