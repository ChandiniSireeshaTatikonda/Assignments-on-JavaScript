// Get Request 

let myPromise = new Promise(function(resolve,reject)
{
var xhr = new XMLHttpRequest();
xhr.open( "GET","http://34.71.224.0:8080/api/tasks" , true); 
xhr.setRequestHeader('Authorization',"Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ1c2VyMSIsImF1dGgiOiJST0xFX1VTRVIiLCJleHAiOjE2MTc0MzMzOTl9._VY8Ao2E4a4C5_3aWpRh3HzPBJPlQ4SWdzAlMObp89r3rEx2jQXs-x_Lz7ozNDZuIdxI9zuExRUFYCQaYwfRUw");
xhr.send();
xhr.onload = function () {
var receivedData = JSON.parse(xhr.responseText);
if (xhr.status >= 200 && xhr.status < 400) {
resolve(receivedData);
}
else {
reject("Not found");
}
}
})
myPromise.then(function(data){
if(data.length === 0){
document.getElementById("empty").innerHTML="No Elements are available in the API";
}
else{ 
for(var i = 0; i<data.length; i++)
{
var tableData = document.getElementById("table");
var row1 = tableData.insertRow(0);
var cell1 = row1.insertCell(0);
cell1.innerHTML = data[i]['name'];
var cell2 = row1.insertCell(1);
cell2.innerHTML = data[i]['expiryDate'];
var cell3 = row1.insertCell(2);
cell3.innerHTML = data[i]['status'];

// Edit Button
var cell4 = row1.insertCell(3);
var buttonForEdit = document.createElement('button');
var buttonName1 = document.createTextNode("EDIT");
buttonForEdit.appendChild(buttonName1);
cell4.appendChild(buttonForEdit);

buttonForEdit.style.color = "#fff";
buttonForEdit.style.background = "DodgerBlue";
buttonForEdit.style.padding = "5px";
buttonForEdit.style.borderRadius = "5px";

var id = data[i]['id'];
var name = data[i]['name'];
var expiryDate = data[i]['expiryDate'];
var status = data[i]['status'];

buttonForEdit.id = id;
buttonForEdit.name = name;
buttonForEdit.expiryDate = expiryDate;
buttonForEdit.status = status;

buttonForEdit.onclick = function () {
        document.getElementById("visible").style.visibility="visible";
        document.getElementById("taskname").value=this.name;
        document.getElementById("time").value=this.expiryDate;
        document.getElementById("status").value=this.status;
        document.getElementById("saveChanges").value=this.id;
    }

// DeleteButton
var cell5 = row1.insertCell(4);
var buttonForDelete = document.createElement('button');
var buttonName2 = document.createTextNode("DELETE");
buttonForDelete.appendChild(buttonName2);
cell5.appendChild(buttonForDelete);

buttonForDelete.style.color = "#fff";
buttonForDelete.style.background = "tomato";
buttonForDelete.style.padding = "5px";
buttonForDelete.style.borderRadius = "5px";

buttonForDelete.id = id;

buttonForDelete.onclick = function (){
// Delete request 
var xhr = new XMLHttpRequest();
xhr.open( "DELETE","http://34.71.224.0:8080/api/tasks/"+this.id,true);
xhr.setRequestHeader('Authorization',"Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ1c2VyMSIsImF1dGgiOiJST0xFX1VTRVIiLCJleHAiOjE2MTc0MzMzOTl9._VY8Ao2E4a4C5_3aWpRh3HzPBJPlQ4SWdzAlMObp89r3rEx2jQXs-x_Lz7ozNDZuIdxI9zuExRUFYCQaYwfRUw");
xhr.setRequestHeader('Content-Type', 'application/json');
xhr.send();
xhr.onload = function () {
if (xhr.status >= 200 && xhr.status < 400) {
  window.location.replace("index.html");
}
else {
    alert("Failed to delete");
 }
}
  };
}
}
// console.log(data);
}).catch(function (err) {
 alert("Failed to load");
 console.log(err);
});

